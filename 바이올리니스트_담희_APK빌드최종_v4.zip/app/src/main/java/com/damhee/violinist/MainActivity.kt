package com.damhee.violinist

import android.Manifest
import android.app.Activity
import android.os.Bundle
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import kotlin.math.*

class MainActivity : Activity() {
    private lateinit var note: TextView
    private lateinit var hz: TextView
    private lateinit var diff: TextView
    private lateinit var needle: TextView
    private var recorder: AudioRecord? = null
    private var running=false
    private var ref=440.0
    private val names=arrayOf("G3","D4","A4","E5")
    private val freqs=arrayOf(196.0,293.6648,440.0,659.2551)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        buildUi()
    }

    private fun buildUi(){
        val bg=ImageView(this).apply{setImageResource(com.damhee.violinist.R.drawable.damhee_bg);scaleType=ImageView.ScaleType.CENTER_CROP}
        val overlay=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER_HORIZONTAL;padding=20}
        val title=TextView(this).apply{text="바이올리니스트 담희♡";textSize=25f;setTextColor(Color.WHITE);gravity=Gravity.CENTER}
        val sub=TextView(this).apply{text="VIOLIN TUNER";textSize=11f;setTextColor(Color.WHITE)}
        note=TextView(this).apply{text="A₄";textSize=72f;setTextColor(Color.WHITE);gravity=Gravity.CENTER}
        hz=TextView(this).apply{text="440.0 Hz";textSize=20f;setTextColor(Color.WHITE)}
        diff=TextView(this).apply{text="튜너 시작을 눌러주세요";textSize=15f;setTextColor(Color.WHITE);gravity=Gravity.CENTER}
        needle=TextView(this).apply{text="┃";textSize=70f;setTextColor(Color.rgb(103,243,139))}
        val start=Button(this).apply{text="🎤 튜너 시작";setOnClickListener{startTuner()}}
        val refBtn=Button(this).apply{text="A = 440 Hz";setOnClickListener{ref=if(ref==440.0)442.0 else 440.0;text="A = ${ref.toInt()} Hz"}}
        overlay.addView(title);overlay.addView(sub)
        overlay.addView(needle,LinearLayout.LayoutParams(-1,150))
        overlay.addView(note);overlay.addView(hz);overlay.addView(diff)
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER}
        names.forEachIndexed{ i,n-> row.addView(Button(this).apply{text=n;setOnClickListener{diff.text="$n 현을 조율하세요"}})}
        overlay.addView(row);overlay.addView(start);overlay.addView(refBtn)
        val frame=FrameLayout(this);frame.addView(bg);frame.addView(overlay)
        setContentView(frame)
    }

    private fun startTuner(){
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO),10); return
        }
        if(running)return
        val sr=44100; val size=AudioRecord.getMinBufferSize(sr,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT)
        recorder=AudioRecord(MediaRecorder.AudioSource.MIC,sr,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT,size*2)
        recorder!!.startRecording();running=true;diff.text="듣고 있어요… 바이올린을 연주해 주세요."
        Thread{ val buf=ShortArray(4096); while(running){ val n=recorder!!.read(buf,0,buf.size); if(n>0){val f=pitch(buf,n,sr); if(f>150&&f<900) runOnUiThread{showPitch(f)}}}}.start()
    }

    private fun pitch(b:ShortArray,n:Int,sr:Int):Double{
        var rms=0.0; for(i in 0 until n){val x=b[i]/32768.0;rms+=x*x}; if(sqrt(rms/n)<.01)return -1.0
        var bestLag=0;var best=0.0
        for(lag in 30 until n/2){var c=0.0;for(i in 0 until n-lag)c+=(b[i].toDouble()*b[i+lag]);if(c>best){best=c;bestLag=lag}}
        return if(bestLag>0)sr.toDouble()/bestLag else -1.0
    }
    private fun showPitch(f:Double){
        val idx=names.indices.minByOrNull{abs(12*ln(f/scaleFreq(freqs[it]))/ln(2.0))} ?: 2
        val target=scaleFreq(freqs[idx]); val cents=1200*ln(f/target)/ln(2.0)
        note.text=names[idx].replace("3","₃").replace("4","₄").replace("5","₅")
        hz.text="%.1f Hz".format(f)
        diff.text=if(abs(cents)<5)"✓ 정확합니다!" else if(cents<0)"%.1f cent 낮아요 ♭".format(abs(cents)) else "%.1f cent 높아요 ♯".format(abs(cents))
        needle.setTextColor(if(abs(cents)<5)Color.rgb(103,243,139) else Color.rgb(255,211,107))
    }
    private fun scaleFreq(f:Double)=f*(ref/440.0)
    override fun onDestroy(){running=false;recorder?.stop();recorder?.release();super.onDestroy()}
}