바이올리니스트 담희♡ - Android APK build v4

이 프로젝트는 GitHub Actions에서 Gradle 8.7을 명시적으로 설치한 뒤 debug APK를 빌드하도록 수정한 버전입니다.
이전 버전에서 발생할 수 있었던 'gradle 명령을 찾을 수 없음' 문제를 피하도록 workflow를 수정했습니다.

앱 이름: 바이올리니스트 담희♡
패키지: com.damhee.violinist
주요 기능: 마이크 음정 감지, G3/D4/A4/E5, A=440/442 Hz, 담희 사진 배경
